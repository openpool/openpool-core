openpool-base-kinect
----------------------------------------------------------------

 This is the base function library for OpenPool project.
 For more detail, please visit http://www.open-pool.com/.

 Copyright (c) takashyx 2012-2013 ( http://takashyx.com )
 Copyright (c) arc@dmz 2012-2013 ( http://junkato.jp )

 All rights reserved.
 This work is licensed under GPL v2.
