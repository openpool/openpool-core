package openpool;

import processing.core.PApplet;

public class DummyPool extends OpenPool {
	public DummyPool(PApplet pa) {
		super(pa, 0);
	}
}
